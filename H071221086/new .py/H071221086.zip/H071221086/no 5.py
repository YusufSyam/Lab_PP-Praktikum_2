a = input ('masukkan string s: ').replace('e','-#-').replace('b',';--;').replace('a','_').replace('c','*').replace('t','<=+=>').replace('n','###').replace(' ','^^^')
print(a)
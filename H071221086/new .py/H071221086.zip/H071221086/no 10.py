a = input('masukkan string s: ').replace('-#-','e').replace(';--;','b').replace('_','a').replace('*','c').replace('<=+=>','t').replace('###','n').replace('^^^',' ')
print(a)
import math

x = int(input('masukkan x: '))
y = int(input('masukkan y: '))

kpk = math.lcm(x,y)
print('KPK dari', x,'dan' ,y, ':',kpk)
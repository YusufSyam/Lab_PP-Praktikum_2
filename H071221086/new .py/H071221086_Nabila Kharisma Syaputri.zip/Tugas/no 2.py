#Program menghitung luas segitiga
#H071221086
from re import A


a= 8
b= 6

alas = a
tinggi = b
luas = 0.5*alas*tinggi

print("luas segitiga: " ,luas)

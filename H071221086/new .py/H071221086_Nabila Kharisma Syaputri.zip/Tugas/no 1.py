#Program perkenalan diri
nama = input('Masukkan nama: ')
nim = input('Masukkan nim: ')

print('\nOutput: ')
print(nama, nim)
